# -*- coding: utf-8 -*-

import datetime
import json
import unicodedata
import codecs
import os

def byteify(input):
    if isinstance(input, dict):
        return {byteify(key): byteify(value)
                for key, value in input.iteritems()}
    elif isinstance(input, list):
        return [byteify(element) for element in input]
    elif isinstance(input, unicode):
        return input.encode('utf-8')
    else:
        return input
      

from flask import Flask
from flask import url_for, render_template, request, redirect

app = Flask(__name__)

data = {'sex':[], 'age':[],'education':[],'region':[],'answ':[]}






@app.route('/')
def main():
   urls = {'Статистика': url_for('stats'),         
            'Вывод всех данных': url_for('json2'),
           'Поиск': url_for('search'),
   }
   if request.args:
        answ = request.args['answ']
        sex = request.args['sex']
        age = request.args['age']
        education = request.args['education']
        region = request.args['region']
        data['sex'].append(sex)
        data['age'].append(age)
        data['education'].append(education)
        data['region'].append(region)
        data['answ'].append(answ)

        with open('data.txt', 'w') as outfile:
            json.dump(data, outfile)

        #return render_template('answer2.html', answ=answ, age=age, sex=sex, education=education, region=region)
   return render_template('main.html', urls=urls)

    
@app.route('/stats')
def stats():
    l=0
    r=0
    b=0
    n=0
    la=0
    ra=0
    ba=0
    na=0
    j=0
    for k in data['answ']:
        
        if k=="left":
            l=l+1
            la=la+int(data['age'][j])
        if k=="right":
            r=r+1
            ra=ra+int(data['age'][j])
        if k=="both":
            b=b+1
            ba=ba+int(data['age'][j])
        if k=="neither":
            n=n+1
            na=na+int(data['age'][j])
            
        j=j+1
    if la!=0:
        la=la/l
    if ra!=0:
        ra=ra/r
    if ba!=0:
        ba=ba/b
    if na!=0:
        na=na/n
    return render_template('stats.html',left=la,right=ra,both=ba,neither=na)


@app.route('/json')
def json2():
   jsondata2 = json.dumps(data, ensure_ascii=False)
   return render_template('json2.html',x=data)

@app.route('/search')
def search():
    if request.args:
        sex = request.args['sex']
        age1 = request.args['age1']
        age2 = request.args['age2']
        return render_template('results.html',age1=age1,age2=age2,sex=sex)
    return render_template('search.html')

@app.route('/results')
def results(): 
    if request.args:
        sex = request.args['sex']
        age1 = request.args['age1']
        age2 = request.args['age2']
        datar = {'sex':[], 'age':[],'education':[],'region':[],'answ':[]}
        j=0
        jj=0
        for k in data['sex']:
            if k==sex:
                if int(data['age'][j])>=int(age1):
                    if int(data['age'][j])<=int(age2):
                        jj=jj+1
                        datar['sex'].append(data['sex'][j])
                        datar['age'].append(data['age'][j])
                        datar['education'].append(data['education'][j])
                        datar['region'].append(data['region'][j])
                        datar['answ'].append(data['answ'][j])
            j=j+1
    return render_template('results.html',age1=age1,age2=age2,sex=sex,x=datar)


   







if __name__ == '__main__':
    app.run(debug=True)
